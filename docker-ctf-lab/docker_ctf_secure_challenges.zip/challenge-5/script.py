import os
import resource
# Simulate check for CPU and memory limit
mem_limit = resource.getrlimit(resource.RLIMIT_AS)[0]
cpu_count = os.cpu_count()
if mem_limit <= 268435456 and cpu_count <= 1:
    print("CTF{resource_limits_applied_correctly}")
else:
    print("Resource limits not applied correctly")